﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVendors.xaml
    /// </summary>
    public partial class PageVendors : Page
    {
        public PageVendors()
        {
            InitializeComponent();
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
        }

        private void MenuAddVendor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVendors(null));
        }

        private void MenuEditVendor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVendors((Vendors)DTGVendor.SelectedItem));
        }


        private void MenuSortNameVendor1_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.OrderBy(x => x.NameVendor).ToList();
        }

        private void MenuSortNameVendor2_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.OrderByDescending(x => x.NameVendor).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
        }

        private void MenuFilterVendor1_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.Where(x => x.Rating <= 2).ToList();
        }

        private void MenuFilterVendor2_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.Where(x => x.Rating >= 2.1 && x.Rating <= 4).ToList();
        }

        private void MenuFilterVendor3_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.Where(x => x.Rating >= 4.1).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
        }

        private void MenuDelVendor_Click(object sender, RoutedEventArgs e)
        {
            var vendorForRemoving = DTGVendor.SelectedItems.Cast<Vendors>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {vendorForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().Vendors.RemoveRange(vendorForRemoving);
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearсhVendor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DTGVendor.ItemsSource != null)
            {
                DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.Where(x => x.NameVendor.ToLower().Contains(SearсhVendor.Text.ToLower())).ToList();
            }
            if (SearсhVendor.Text.Count() == 0) DTGVendor.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
        }
    }
}
