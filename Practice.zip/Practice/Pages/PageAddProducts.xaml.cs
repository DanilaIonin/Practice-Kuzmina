﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddProducts.xaml
    /// </summary>
    public partial class PageAddProducts : Page
    {
        private Products _currentProducts = new Products();
        public PageAddProducts(Products selectedProduct)
        {
            InitializeComponent();
            if (selectedProduct != null)
            {
                _currentProducts = selectedProduct;
                TitletxProduct.Text = "Изменение товара";
                BtnAddProduct.Content = "Изменить";
            }
            DataContext = _currentProducts;
            CMBCategories.ItemsSource = CommodityWarehouseEntities.GetContext().Category.ToList();
            CMBCategories.SelectedValuePath = "IDCategory";
            CMBCategories.DisplayMemberPath = "NameCategory";

            CMBVendors.ItemsSource = CommodityWarehouseEntities.GetContext().Vendors.ToList();
            CMBVendors.SelectedValuePath = "IDVendor";
            CMBVendors.DisplayMemberPath = "NameVendor";

            CMBWarehouses.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
            CMBWarehouses.SelectedValuePath = "IDWarehouse";
            CMBWarehouses.DisplayMemberPath = "NameWarehouse";
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentProducts.NameProducts)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.Price))) error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(_currentProducts.Unit)) error.AppendLine("Укажите ед. измерения");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.Count))) error.AppendLine("Укажите количество");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.IDCategory))) error.AppendLine("Укажите категорию");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.IDVendor))) error.AppendLine("Укажите поставщика");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProducts.IDWarehouse))) error.AppendLine("Укажите склад");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentProducts.IDProducts == 0)
            {
                CommodityWarehouseEntities.GetContext().Products.Add(_currentProducts);
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProducts());
                    MessageBox.Show("Новый товар успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProducts());
                    MessageBox.Show("Товар успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageProducts());
        }
    }
}
