﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;
using Practice.Pages;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageWarehouses.xaml
    /// </summary>
    public partial class PageWarehouses : Page
    {
        public PageWarehouses()
        {
            InitializeComponent();
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
        }

        private void MenuAddWarehouse_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddWarehouses(null));
        }

        private void MenuEditWarehouse_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddWarehouses((Warehouse)DTGWarehouse.SelectedItem));
        }


        private void MenuSortNameWarehouse1_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.OrderBy(x => x.NameWarehouse).ToList();
        }

        private void MenuSortNameWarehouse2_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.OrderByDescending(x => x.NameWarehouse).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
        }

        private void MenuFilterWarehouse1_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.Where(x => x.AreaWarehouse <= 5000).ToList();
        }

        private void MenuFilterWarehouse2_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.Where(x => x.AreaWarehouse >= 5001 && x.AreaWarehouse <= 7500).ToList();
        }

        private void MenuFilterWarehouse3_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.Where(x => x.AreaWarehouse >= 7500).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
        }

        private void MenuDelWarehouse_Click(object sender, RoutedEventArgs e)
        {
            var warehouseForRemoving = DTGWarehouse.SelectedItems.Cast<Warehouse>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {warehouseForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().Warehouse.RemoveRange(warehouseForRemoving);
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearсhWarehouse_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DTGWarehouse.ItemsSource != null)
            {
                DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.Where(x => x.NameWarehouse.ToLower().Contains(SearсhWarehouse.Text.ToLower())).ToList();
            }
            if (SearсhWarehouse.Text.Count() == 0) DTGWarehouse.ItemsSource = CommodityWarehouseEntities.GetContext().Warehouse.ToList();
        }
    }
}
