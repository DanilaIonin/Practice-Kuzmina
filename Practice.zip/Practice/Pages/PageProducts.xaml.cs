﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;


namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProducts.xaml
    /// </summary>
    public partial class PageProducts : Page
    {
        public PageProducts()
        {
            InitializeComponent();
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
        }

        private void MenuAddProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddProducts(null));
        }

        private void MenuEditProduct_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddProducts((Products)DTGProduct.SelectedItem));
        }

        private void MenuExportToExcelProduct_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Договор.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[46, 2] = "Дата:";
            ws.Cells[46, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = "Договор №17";
            int indexRows = 6;
            ws.Cells[2][4] = "Товары";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Название";
            ws.Cells[3][indexRows] = "Цена";
            ws.Cells[4][indexRows] = "Ед.измерения";
            ws.Cells[5][indexRows] = "Количество";
            ws.Cells[6][indexRows] = "Категория";
            ws.Cells[7][indexRows] = "Поставщик";
            ws.Cells[8][indexRows] = "Склад";
            ws.Cells[9][indexRows] = "Сумма";
            var printItems = DTGProduct.Items;
            foreach (Products item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.NameProducts;
                ws.Cells[3][indexRows + 1] = item.Price;
                ws.Cells[4][indexRows + 1] = item.Unit;
                ws.Cells[5][indexRows + 1] = item.Count;
                ws.Cells[6][indexRows + 1] = item.Category.NameCategory;
                ws.Cells[7][indexRows + 1] = item.Vendors.NameVendor;
                ws.Cells[8][indexRows + 1] = item.Warehouse.NameWarehouse;
                ws.Cells[9][indexRows + 1] = item.Sum;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 7] = "Подпись";
            ws.Cells[indexRows + 2, 8] = "Ионин Д.В.";
            excelApp.Visible = true;
        }
        private void MenuSortNameProduct1_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.OrderBy(x => x.NameProducts).ToList();
        }

        private void MenuSortNameProduct2_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.OrderByDescending(x => x.NameProducts).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
        }

        private void MenuFilterProduct1_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.Where(x => x.Price <= 250).ToList();
        }

        private void MenuFilterProduct2_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.Where(x => x.Price >= 251 && x.Price <=500).ToList();
        }

        private void MenuFilterProduct3_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.Where(x => x.Price >= 501).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
        }

        private void MenuDelProduct_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DTGProduct.SelectedItems.Cast<Products>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {productForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().Products.RemoveRange(productForRemoving);
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }   
            }
        }

        private void SearсhUnit_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DTGProduct.ItemsSource != null)
            {
                DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.Where(x => x.Unit.ToLower().Contains(SearсhUnit.Text.ToLower())).ToList();
            }
            if (SearсhUnit.Text.Count() == 0) DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
        }

        private void SearсhWarehouse_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DTGProduct.ItemsSource != null)
            {
                DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.Where(x => x.Warehouse.NameWarehouse.ToLower().Contains(SearсhWarehouse.Text.ToLower())).ToList();
            }
            if (SearсhWarehouse.Text.Count() == 0) DTGProduct.ItemsSource = CommodityWarehouseEntities.GetContext().Products.ToList();
        }

       
    }
}
