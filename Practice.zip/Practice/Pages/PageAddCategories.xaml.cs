﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddCategories.xaml
    /// </summary>
    public partial class PageAddCategories : Page
    {
        private Category _currentCategorie = new Category();
        public PageAddCategories(Category selectedCategorie)
        {
            InitializeComponent();
            if (selectedCategorie != null)
            {
                _currentCategorie = selectedCategorie;
                TitletxCategorie.Text = "Изменение категории";
                BtnAddCategorie.Content = "Изменить";
            }
            DataContext = _currentCategorie;
        }

        private void BtnAddCategorie_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentCategorie.NameCategory)) error.AppendLine("Укажите название");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentCategorie.IDCategory == 0)
            {
                CommodityWarehouseEntities.GetContext().Category.Add(_currentCategorie);
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCategories());
                    MessageBox.Show("Новая категория успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCategories());
                    MessageBox.Show("Категория успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelCategorie_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCategories());
        }
    }
}
