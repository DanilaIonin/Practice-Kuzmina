﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddWarehouses.xaml
    /// </summary>
    public partial class PageAddWarehouses : Page
    {
        private Warehouse _currentWarehouses = new Warehouse();
        public PageAddWarehouses(Warehouse selectedWarehouse)
        {
            InitializeComponent();
            if (selectedWarehouse != null)
            {
                _currentWarehouses = selectedWarehouse;
                TitletxWarehouse.Text = "Изменение склада";
                BtnAddWarehouse.Content = "Изменить";
            }
            DataContext = _currentWarehouses;
        }

        private void BtnAddWarehouse_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentWarehouses.NameWarehouse)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(_currentWarehouses.Adress)) error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentWarehouses.AreaWarehouse))) error.AppendLine("Укажите площадь");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentWarehouses.IDWarehouse == 0)
            {
                CommodityWarehouseEntities.GetContext().Warehouse.Add(_currentWarehouses);
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageWarehouses());
                    MessageBox.Show("Новый склад успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageWarehouses());
                    MessageBox.Show("Склад успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelWarehouse_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageWarehouses());
        }
    }
}
