﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Practice.Classes;

namespace Practice.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddVendors.xaml
    /// </summary>
    public partial class PageAddVendors : Page
    {
        private Vendors _currentVendors = new Vendors();
        public PageAddVendors(Vendors selectedVendor)
        {
            InitializeComponent();
            if (selectedVendor != null)
            {
                _currentVendors = selectedVendor;
                TitletxVendor.Text = "Изменение поставщика";
                BtnAddVendor.Content = "Изменить";
            }
            DataContext = _currentVendors;
        }

        private void BtnAddVendor_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentVendors.NameVendor)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(_currentVendors.AdressVendor)) error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(_currentVendors.PhoneVendor)) error.AppendLine("Укажите телефон");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVendors.Rating))) error.AppendLine("Укажите рейтинг");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentVendors.IDVendor == 0)
            {
                CommodityWarehouseEntities.GetContext().Vendors.Add(_currentVendors);
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVendors());
                    MessageBox.Show("Новый поставщик успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    CommodityWarehouseEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVendors());
                    MessageBox.Show("Поставщик успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelVendor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVendors());
        }
    }
}
